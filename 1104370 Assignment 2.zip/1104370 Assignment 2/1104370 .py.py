"""## Import data preprocessing libraries"""

import pandas as pd
import os
import numpy as np

"""## Read the data and process. And convert string to int"""

X = []
optimized_values = []

# Read every file one by one
for file in os.listdir("DS"):
    # Read a file
    df = pd.read_csv(os.path.join("DS", file))

    # Convert optmizied value to int and add it to the array
    optimized_values.append(float(df.columns[0].split(':')[1]))

    # Go through every row of csv file and convert all values to int
    data = []
    for row_number, row in enumerate(df.iterrows()):

        # Every waiting time is expressed in 3 rows so 3 row data will consititute to 1 row in processed data
        if(row_number%3 == 0):
            data_row = []

        # Remove '[, ], "" ' from the string
        tokens = (row[1][0]).split(' ')
        for token in tokens:
            start = 0
            end = len(token)
            if(token == ''):
                continue
            elif(token[:2] == "[["):
                start += 2
            elif(token[:1] == "["):
                start += 1
            elif(token[-2:] == "]]"):
                end -= 2
            elif(token[-1:] == "]"):
                end -= 1
            if(end == start):
                continue
            data_row.append(int(token[start:end]))
        if(row_number%3 == 2):
            data.append(data_row)
    X.append(np.array(data))

# Convert X to numpy array
X = np.array(X)
print(X.shape)
print(len(optimized_values))

X_copy = X
optimized_values_copy = optimized_values

"""# ANN

## Divide the data into training and testing
"""

from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X_copy, optimized_values_copy, test_size=0.1, random_state=42)

y_train = np.array(y_train)
y_test = np.array(y_test)
print(X_train.shape)
print(len(y_train))
print(X_test.shape)
print(len(y_test))

"""## Reshape them to convert to a 1-D array from 2-D array"""

X_train = X_train.reshape((900, -1))
X_test = X_test.reshape((100, -1))
print(X_train.shape)
print(X_test.shape)

"""## Apply the standardization"""

from sklearn.preprocessing import StandardScaler
scaler = StandardScaler()
scaler.fit(X_train)
X_train = scaler.transform(X_train)
X_test = scaler.transform(X_test)

"""## Import the machine learning library"""

from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense
from tensorflow.keras.optimizers import SGD, Adam
from tensorflow.keras.layers import Dropout
import tensorflow as tf

"""## Make the ANN"""

model = Sequential()
model.add(Dense(128, input_shape=(2500,), activation="tanh"))
model.add(Dense(32, activation="tanh"))
model.add(Dense(1, activation="linear"))

"""## Compile the model and print the summary"""

INIT_LR = 0.01
EPOCHS = 360
opt = Adam(lr=INIT_LR)
model.compile(loss="mean_squared_error", optimizer=opt, metrics=[tf.keras.metrics.RootMeanSquaredError()])
model.summary()

"""## Fit the model (training)"""

history = model.fit(X_train, y_train, epochs=EPOCHS, validation_data = (X_test, y_test))

"""## Save the model"""

import h5py
model.save('1104370_ANN.h5')

"""## Load the model"""

from tensorflow.keras.models import load_model
ann_model = load_model('1104370_ANN.h5')

"""## Plot the results"""

# Commented out IPython magic to ensure Python compatibility.
import matplotlib.pyplot as plt
# %matplotlib inline
# summarize history for accuracy
plt.plot(history.history['root_mean_squared_error'])
plt.plot(history.history['val_root_mean_squared_error'])
plt.title('Root mean squared error graph ANN model')
plt.ylabel('Root mean squared error')
plt.xlabel('epoch')
plt.legend(['train', 'test'], loc='upper left')

pred = model.predict(X_test)
plt.figure(figsize=(10, 10))
plt.scatter(y_test, pred)
plt.title('Output graph ANN model')
plt.xlabel('True Values ')
plt.ylabel('Predictions ')
plt.axis('equal')
plt.axis('square')

"""# CNN"""

import numpy as np

X_copy = X
optimized_values_copy = optimized_values

"""## Divide the data into train and test"""

from sklearn.model_selection import train_test_split
X_train_cnn, X_test_cnn, y_train_cnn, y_test_cnn = train_test_split(X_copy, optimized_values_copy, test_size=0.1, random_state=42)

y_train_cnn =  np.array(y_train_cnn)
y_test_cnn = np.array(y_test_cnn)

"""## Reshape the data from 2-D to 1-D so that we can apply standardScaler in the next step"""

X_train_cnn = X_train_cnn.reshape((900, -1))
X_test_cnn = X_test_cnn.reshape((100, -1))
print(X_train_cnn.shape)
print(X_test_cnn.shape)

"""## Apply the standardization"""

from sklearn.preprocessing import StandardScaler
scaler = StandardScaler()
scaler.fit(X_train_cnn)
X_train_cnn = scaler.transform(X_train_cnn)
X_test_cnn = scaler.transform(X_test_cnn)

"""## Reshape the data from 1-D to 3-D to be fed to convolutional neural network"""

X_train_cnn = X_train_cnn.reshape((900, 50, 50, 1))
X_test_cnn = X_test_cnn.reshape((100, 50, 50, 1))
print(X_train_cnn.shape)
print(X_test_cnn.shape)

"""## Import the machine learning libraries"""

from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Conv2D
from tensorflow.keras.layers import MaxPooling2D
from tensorflow.keras.layers import Activation
from tensorflow.keras.layers import Flatten
from tensorflow.keras.layers import Dropout
from tensorflow.keras.layers import Dense
from tensorflow.keras.optimizers import SGD, Adam
import tensorflow as tf

"""## Make the model architecture"""

cnn_model = Sequential()
cnn_model.add(Conv2D(32, (3, 3), padding="same", input_shape=(50, 50, 1)))
cnn_model.add(Activation("tanh"))
cnn_model.add(Flatten())
cnn_model.add(Dense(1, activation = 'linear'))

"""## Compile the model and print the summary"""

INIT_LR = 0.01
EPOCHS = 50
opt = Adam(lr=INIT_LR, decay=INIT_LR / EPOCHS)
cnn_model.compile(loss="MSE", optimizer=opt, metrics=[tf.keras.metrics.RootMeanSquaredError()])
cnn_model.summary()

"""## Fit the model"""

history = cnn_model.fit(X_train_cnn, y_train_cnn, validation_data=(X_test_cnn, y_test_cnn), epochs=EPOCHS, verbose=1)

"""## Save the model"""

import h5py
cnn_model.save('1104370_CNN.h5')

"""## Load the model"""
from tensorflow.keras.models import load_model
cnn_model = load_model('1104370_CNN.h5')

"""## Plot the results"""

# Commented out IPython magic to ensure Python compatibility.
import matplotlib.pyplot as plt
# %matplotlib inline
# summarize history for accuracy
plt.plot(history.history['root_mean_squared_error'])
plt.plot(history.history['val_root_mean_squared_error'])
plt.title('Root mean squared error graph CNN model')
plt.ylabel('Root mean squared error')
plt.xlabel('epoch')
plt.legend(['train', 'test'], loc='upper left')

# Commented out IPython magic to ensure Python compatibility.
import matplotlib.pyplot as plt
# %matplotlib inline

pred = cnn_model.predict(X_test_cnn)
plt.figure(figsize=(10, 10))
plt.scatter(y_test, pred)
plt.xlabel('True Values ')
plt.ylabel('Predictions ')
plt.title('Output graph CNN model')
plt.axis('equal')
plt.axis('square')

"""# Compare the results of different models"""

from sklearn.metrics import mean_squared_error
from math import sqrt

cnn_output = cnn_model.predict(X_test_cnn)
ann_output = model.predict(X_test)
cnn_rms = sqrt(mean_squared_error(y_test, cnn_output))
ann_rms = sqrt(mean_squared_error(y_test, ann_output))

import pandas as pd
df = pd.DataFrame({"CNN RMSE":[cnn_rms], "ANN RMSE":[ann_rms]})
df.plot(kind='bar')
plt.title("Comparison graph")
plt.show()