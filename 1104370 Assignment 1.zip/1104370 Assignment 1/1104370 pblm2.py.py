import gurobipy as grb

# Set of doctors
Doctors = ["Doctor 1", "Doctor 2", "Doctor 3", "Doctor 4", "Doctor 5", "Doctor 6"]

# Set of patients
Patients = ["Patient 1", "Patient 2", "Patient 3", "Patient 4", "Patient 5", "Patient 6"]

# Times of each doctor to treat each patient
Times = {"Doctor 1": {"Patient 1": 90, "Patient 2": 106, "Patient 3": 76, "Patient 4":144, "Patient 5":122, "Patient 6":88},
"Doctor 2": {"Patient 1": 114, "Patient 2": 53, "Patient 3": 63, "Patient 4":70, "Patient 5":120, "Patient 6":94},
"Doctor 3": {"Patient 1": 52, "Patient 2": 59, "Patient 3": 90, "Patient 4":150, "Patient 5":90, "Patient 6":146},
"Doctor 4": {"Patient 1": 130, "Patient 2": 95, "Patient 3": 94, "Patient 4":139, "Patient 5":86, "Patient 6":59},
"Doctor 5": {"Patient 1": 118, "Patient 2": 83, "Patient 3": 52, "Patient 4":66, "Patient 5":91, "Patient 6":77},
"Doctor 6": {"Patient 1": 123, "Patient 2": 82, "Patient 3": 64, "Patient 4":141, "Patient 5":82, "Patient 6":77}}


# Calling the optimization Model
opt_model = grb.Model(name="MIP Model")

# Variables: Binary variable which is 1 if patient i is treated by doctor j
x  = {(i,j): opt_model.addVar(vtype=grb.GRB.BINARY, 
                        name="x_{0}_{1}".format(i,j)) 
for i in Patients for j in Doctors}

# Constraints: exactly one doctor per patient
OnePatientPerDoctor = {j :
opt_model.addConstr(
        lhs=grb.quicksum(x[i,j] for i in Patients),
        sense=grb.GRB.EQUAL,
        rhs=1, 
        name="OnePatientPerDoctor_{0}".format(j))
    for j in Doctors}

# Constraints: exactly patient per doctor
OneDoctorPerPatient = {i :
opt_model.addConstr(
        lhs=grb.quicksum(x[i,j] for j in Doctors),
        sense=grb.GRB.EQUAL,
        rhs=1, 
        name="OneDoctorPerPatient_{0}".format(i))
    for i in Patients}

# Objective Function: Minimize total time
objective = grb.quicksum(Times[j][i]*x[i,j] for i in Patients for j in Doctors)
opt_model.ModelSense = grb.GRB.MINIMIZE
opt_model.setObjective(objective)

# Run model
opt_model.optimize()

# Printing results - only the row and column index of selected cells
for v in opt_model.getVars():
  if(v.x > 0):
    print('%s %g' % (v.varName, v.x))
