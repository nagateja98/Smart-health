import gurobipy as grb

# Set of doctors
Doctors = ["Doctor 3", "Doctor 4"]

# Set of patients
Patients = ["Patient 1", "Patient 2"]

# Times of each doctor to treat each patient
Times = {"Doctor 3": {"Patient 1": 130, "Patient 2": 95},
"Doctor 4": {"Patient 1": 118, "Patient 2": 83}}

# Calling the optimization Model
opt_model = grb.Model(name="MIP Model")

# Variables: Binary variable which is 1 if patient i is treated by doctor j
x  = {(i,j): opt_model.addVar(vtype=grb.GRB.BINARY, 
                        name="x_{0}_{1}".format(i,j)) 
for i in Patients for j in Doctors}

# Constraints: exactly one doctor per patient
OnePatientPerDoctor = {j :
opt_model.addConstr(
        lhs=grb.quicksum(x[i,j] for i in Patients),
        sense=grb.GRB.EQUAL,
        rhs=1, 
        name="OnePatientPerDoctor_{0}".format(j))
    for j in Doctors}

# Constraints: exactly patient per doctor
OneDoctorPerPatient = {i :
opt_model.addConstr(
        lhs=grb.quicksum(x[i,j] for j in Doctors),
        sense=grb.GRB.EQUAL,
        rhs=1, 
        name="OneDoctorPerPatient_{0}".format(i))
    for i in Patients}

# Objective Function: Minimize total time
objective = grb.quicksum(Times[j][i]*x[i,j] for i in Patients for j in Doctors)
opt_model.ModelSense = grb.GRB.MINIMIZE
opt_model.setObjective(objective)

# Run model
opt_model.optimize()

# Printing results - only the row and column index of selected cells
for v in opt_model.getVars():
  if(v.x > 0):
    print('%s %g' % (v.varName, v.x))
